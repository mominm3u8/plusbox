<?php


$d0 = @$_GET["id"];
if(isset($d0)){ $d0 = base64_decode($d0); 
$ROLEX = json_decode(file_get_contents("https://jazz-tv.developed-by-iron-man.workers.dev")); 
$n2 = "http://{$ROLEX->url}/stalker_portal/server/load.php?type=itv&action=create_link&cmd=ffrt%20http://localhost/ch/{$d0}&series=&forced_storage=0&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml"; 
$t4 = array( "Cookie: mac=" . base64_decode($ROLEX->mac),
"Authorization: Bearer {$ROLEX->token}",
"Referer: http://{$ROLEX->url}/stalker_portal/c/",
"User-Agent: Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
"X-User-Agent: Model: MAG250; Link:",
"Referer: http://{$ROLEX->url}/stalker_portal/c/" ); 
$n3 = curl_init(); curl_setopt($n3, CURLOPT_URL, $n2);
curl_setopt($n3, CURLOPT_SSL_VERIFYHOST, false); 
curl_setopt($n3, CURLOPT_SSL_VERIFYPEER, false); 
curl_setopt($n3, CURLOPT_RETURNTRANSFER, true); curl_setopt($n3, CURLOPT_HTTPHEADER, $t4);
curl_setopt($n3, CURLOPT_USERAGENT, 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3'); 
curl_setopt($n3, CURLOPT_REFERER, "http://{$ROLEX->url}/stalker_portal/c/"); 
$h5 = curl_exec($n3); curl_close($n3); $i6 = json_decode($h5, true);
if (isset($i6["js"]["cmd"])) 
{ $d7 = $i6["js"]["cmd"]; 
header("Location: " . $d7); die; 
    //var_dump($i6);
   
} } else { echo ''; echo 'Download the latest update from here'; echo 'Playlist'; }


?>